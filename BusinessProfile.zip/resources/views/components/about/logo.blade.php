<div class="my-10 md:my-16">
    <h2 class="
        mb-4
        text-2xl
        font-bold
        text-center text-gray-800
        lg:text-3xl
        md:mb-6
      ">
      Our Logo
    </h2>

    <p class="max-w-screen-md mx-auto text-center text-gray-500 md:text-lg">
      Lorem ipsum dolor sit, amet consectetur adipisicing elit. Facilis
      perspiciatis omnis aspernatur impedit vel, consectetur laudantium nulla et
      aliqua
    </p>
  </div>

<div class=" mt-20">
    <div class="grid gap-4 md:grid-cols-5">
        <div class="p-4 ">
            <img src="{{asset('assets/All logo/b profile.png')}}" alt="Image" class="" />
        </div>
        <div class="p-4 ">
            <img src="{{asset('assets/All logo/baits.png')}}" alt="Image" class="" />
        </div>
        <div class="p-4 ">
            <img src="{{asset('assets/All logo/glam.png')}}" alt="Image" class="" />
        </div>
        <div class="p-4 ">
            <img src="{{asset('assets/All logo/hajj.png')}}" alt="Image" class="w-40" />
        </div>
        <div class="p-4 ">
            <img src="{{asset('assets/All logo/hatbd.png')}}" alt="Image" class="" />
        </div>
        <div class="p-4 ">
            <img src="{{asset('assets/All logo/kazkormo.png')}}" alt="Image" class="" />
        </div>
        <div class="p-4 ">
            <img src="{{asset('assets/All logo/nedubd.png')}}" alt="Image" class="" />
        </div>
        <div class="p-4 ">
            <img src="{{asset('assets/All logo/SKSA Bangladesh.png')}}" alt="Image" class="w-40" />
        </div>
        <div class="p-4 ">
            <img src="{{asset('assets/All logo/techzone.png')}}" alt="Image" class="" />
        </div>   
    </div>
</div>


 