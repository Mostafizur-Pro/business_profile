<div class="m-10">
    <h2 class="text-3xl text-center my-10 font-bold">Find Our Location</h2>
</div>
<div class="aspect-w-16 aspect-h-9">
    <iframe 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3649.8619579860597!2d90.36250424105654!3d23.82350729244121!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c13ac13ad049%3A0xb229d29380cbb2bd!2sAlba%20Tower%2C%20Begum%20Rokeya%20Ave%2C%20Dhaka%201216!5e0!3m2!1sen!2sbd!4v1694496806107!5m2!1sen!2sbd" 
        width="100%" 
        height="400" 
        style="border:0;" 
        allowfullscreen="" 
        loading="lazy" 
        referrerpolicy="no-referrer-when-downgrade">
    </iframe>
</div>
