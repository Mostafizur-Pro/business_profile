@extends('layouts.app.app')
@section('content')



<div>
    <!-- Cover Page -->
    @section('coverText', 'Product')
    @section('coverMenu', 'Companies')
    @include('components/cover/coverText')
    <!-- Cover Page -->

    About Page
</div>

@endsection