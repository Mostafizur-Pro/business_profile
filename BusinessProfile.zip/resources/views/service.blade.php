@extends('layouts.app.app')
@section('content')
@section('title', 'Service')




<div>

    <!-- Cover Page -->
    @section('cover', 'Service')
    @include('components/cover/cover')
    <!-- Cover Page -->

    Service Page



    

</div>

@endsection