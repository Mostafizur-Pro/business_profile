<div class="carousel-inner mb-5">
    <div class="carousel-item active" data-bs-interval="10000">
        <img src="/images/cover_page/client_cover.jpg" class="d-block w-100" alt="...">
        <div class="carousel-caption  d-none  d-md-block  text-center " style="color: #282560;">
            <!-- <h1 class="fw-bold">Our Clients List</h1> -->
            <h1 class="fw-bold">@yield('coverTitle', 'Default Title')</h1>
            <!-- <p class="card-text">Explore The Experiences and Feedback of Our Clients</p> -->
            <p class="card-text">@yield('coverParagraph', 'Default Title')s</p>
        </div>
    </div>
</div>

