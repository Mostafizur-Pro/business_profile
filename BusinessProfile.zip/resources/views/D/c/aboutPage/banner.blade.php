<div class="row h-100 align-items-center py-5">
    <div class="col-lg-6">
        <h1 class="display-4">About us </h1>
        <h3 class="">Connecting Businesses to the World </h3>
        <p class="lead text-muted mb-0">Business Profile is a project of IITAB (International IT Association of Bangladesh) that is working to bring all the legal business out there in the front line. Our main goal is to introduce both the Business and the Business owner to each and every corner of Bangladesh as well as the whole world. From remote area businesses to urban giant businesses, our journey aims to centralize them in a single place.</p>
        <p class="lead text-muted">Snippet by <a href="https://bootstrapious.com/snippets" class="text-muted">
                <u>businesseprofile.com</u></a>
        </p>
    </div>
    <div class="col-lg-6 d-none d-lg-block"><img src="https://bootstrapious.com/i/snippets/sn-about/illus.png" alt="" class="img-fluid"></div>
</div>